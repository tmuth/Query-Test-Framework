--sql_id 5nppz6cmrcy13

select /*+ monitor */ sum(AMOUNT_SOLD) from sales
