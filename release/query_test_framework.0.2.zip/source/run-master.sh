

./alter-system.sh default_plan2.sql
./run-all.d7.sh
./run-all.d7.sh
./run-all.imo.d7.sh
./run-all.imo.d7.sh
./run-all.imo.d7.sh





./alter-system.sh default_plan3.sql

./run-all.d7.sh
./run-all.d7.sh
./run-all.imo.d7.sh
./run-all.imo.d7.sh
./run-all.imo.d7.sh






./alter-system.sh default_plan4.sql


./run-all.d7.sh
./run-all.d7.sh
./run-all.imo.d7.sh
./run-all.imo.d7.sh
./run-all.imo.d7.sh
