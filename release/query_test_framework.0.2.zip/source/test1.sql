--sql_id bh3khmgrtch25

select /*+ monitor  opt_estimate(table, s, rows=1) */ sum(AMOUNT_SOLD) from sale

