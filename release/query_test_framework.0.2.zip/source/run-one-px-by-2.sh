#!/bin/bash
FILENAME='rtl1.sql'

echo "Bash version ${BASH_VERSION}..."
for i in {0..10..2}
  do
     echo "Welcome $i times"
 done



for f in $FILES
do
  echo "Processing $f file..."
  queryname=`echo "$f" | sed 's/\..\{3\}$//' | sed 's/[\/|\.]//g'`
  \sqlplus d56/d56 @query-capture.sql $f $queryname  null.sql
done



for i in ${farm_hosts[@]}; do
        su $login -c "scp $httpd_conf_new ${i}:${httpd_conf_path}"
        su $login -c "ssh $i sudo /usr/local/apache/bin/apachectl graceful"

done


dop_list=(128 256 512 564 660)
foo="hello"
for i in ${dop_list[@]}; do
	echo $i
	bar="$foo.$i"
	echo $bar
done